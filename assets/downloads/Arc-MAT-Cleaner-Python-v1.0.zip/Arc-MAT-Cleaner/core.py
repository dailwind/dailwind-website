"""Arc MAT Cleaner: independent preparation and preflight, not a linguistic tagger."""
from __future__ import annotations
import csv, json, re, threading, tempfile, unicodedata
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path

EXCLUDE = re.compile(r'_\W|\[\w+\]|_POS', re.ASCII)
PENN = set('CC CD DT EX FW IN JJ JJR JJS LS MD NN NNS NNP NNPS PDT POS PRP PRP$ RB RBR RBS RP SYM TO UH VB VBD VBG VBN VBP VBZ WDT WP WP$ WRB -LRB- -RRB-'.split())

@dataclass
class Options:
    mode: str = 'raw'
    controls: bool = True
    softHyphens: bool = True
    punctuation: bool = True
    spacing: bool = True
    ligatures: bool = False
    dehyphenate: bool = False
    boxes: bool = False
    ttr: int = 400

def safe_name(name: str, tagged=False):
    stem = re.sub(r'\.txt$', '', name, flags=re.I)
    stem = re.sub(r'[\x00-\x1f<>:"/\\|?*]', '_', stem).lstrip('.').strip()[:110] or 'document'
    # Windows device names cannot be used even with an extension.
    if stem.split('.')[0].upper() in {'CON','PRN','AUX','NUL',*[f'COM{i}' for i in range(1,10)],*[f'LPT{i}' for i in range(1,10)]}:
        stem = 'file_' + stem
    if tagged:
        stem = re.sub(r'_MAT$', '', stem, flags=re.I) + '_MAT'
    return stem.rstrip(' .') + '.txt'

def process(raw: str, options: Options | None = None, name='document.txt'):
    o = options or Options()
    text, audit = raw, []
    def apply(rule, fn):
        nonlocal text
        before = text
        text = fn(text)
        if text != before: audit.append({'rule':rule,'before':len(before),'after':len(text)})
    apply('Normalize line endings and remove BOM',lambda s:s.removeprefix('\ufeff').replace('\r\n','\n').replace('\r','\n'))
    if o.controls:
        apply('Remove NUL, unsafe controls and zero-width artifacts',lambda s:re.sub(r'[\x00-\x08\x0b\x0e-\x1f\x7f\u200b-\u200f\u202a-\u202e\u2060\u2066-\u2069\ufeff]','',s).replace('\f','\n\n'))
    if o.softHyphens: apply('Remove soft hyphens',lambda s:s.replace('\u00ad',''))
    if o.mode == 'raw':
        if o.punctuation:
            def punct(s):
                return re.sub('[‘’ʼ]',"'",s).replace('“','"').replace('”','"').replace('\u00a0',' ').replace('\u202f',' ').replace('–',' -- ').replace('—',' -- ').replace('…','...')
            apply('Standardize selected punctuation / spaces',punct)
        if o.ligatures: apply('Expand printing ligatures / long s',lambda s:re.sub('[ﬀﬁﬂﬃﬄſ]',lambda m:{'ﬀ':'ff','ﬁ':'fi','ﬂ':'fl','ﬃ':'ffi','ﬄ':'ffl','ſ':'s'}[m[0]],s))
        if o.dehyphenate: apply('Join line-end hyphens (review required)',lambda s:re.sub(r'([A-Za-z])-\s*\n\s*([a-z])',r'\1\2',s))
        if o.boxes: apply('Remove selected OCR placeholders (letters are not recovered)',lambda s:re.sub('[\ufffd\u25a0\u25a1\u25af]','',s))
    if o.spacing:
        apply('Normalize horizontal spacing / excess blank lines' if o.mode=='raw' else 'Normalize token spacing only; preserve tag spellings',lambda s:re.sub(r'\n{3,}','\n\n',re.sub(r' *\n *','\n',re.sub(r'[\t \u0085\u00a0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000]+',' ',s))).strip())
    tokens = text.split()
    baseline = sum(not EXCLUDE.search(m[0]) for m in re.finditer(r'[^\t\n\v\f\r ]+',text))
    tagged = untagged = bracket = penn = 0
    bad, warnings = [], []
    for token in tokens:
        if re.fullmatch(r'\[[A-Za-z0-9_]+\]',token): bracket += 1; continue
        m = re.fullmatch(r'(.+)_([^\s]+)',token)
        if m:
            tagged += 1
            penn += m[2] in PENN
            if not re.fullmatch(r'[A-Z][A-Z0-9$-]*|[.,:;!?`\'"#$()-]+',m[2]) and len(bad)<12: bad.append(token[:100])
        else:
            untagged += 1
            if len(bad)<12: bad.append(token[:100])
    letters = sum(c.isascii() and c.isalpha() for c in text)
    non_ascii = sum(ord(c)>127 for c in text)
    if re.search('[\ufffd\u25a0\u25a1\u25af]',text): warnings.append('Replacement characters / OCR boxes remain; inspect the source. Missing text cannot be reconstructed.')
    if non_ascii: warnings.append(f'{non_ascii} non-ASCII characters remain. Review encoding; MAT is an English analysis tool.')
    if not text.strip() or not letters:
        status,bucket,reason='Blocked','review','Empty or no Latin-letter content. Do not send this file to MAT counting.'
    elif o.mode=='raw':
        if tagged or bracket: status,bucket,reason='Review','review','Tag-like content detected in plain-text mode. Switch to tagged preflight; do not strip existing annotations.'
        else: status,bucket,reason='Tag first','ready-for-tagging','Prepared plain text. Use MAT Tag or Tag and Analyze; do not use Count/Analyze directly.'
    elif not baseline:
        status,bucket,reason='Blocked','review','Zero counter-baseline tokens: this can trigger the division-by-zero condition at count_only.pl line 100.'
    elif not tagged or untagged or bad:
        status,bucket,reason='Review','review','Missing or malformed word_TAG tokens. Re-tag from the original text; renaming a file does not create valid MAT annotations.'
    elif not re.search(r'_MAT\.txt$',name,re.I):
        status,bucket,reason='Review','review','Tagged syntax found, but filename is not *_MAT.txt. Confirm that this is the final MAT output, not Stanford-only POS output.'
    else:
        status,bucket,reason='Preflight passed','count-input','Nonzero baseline and word_TAG syntax checked. This is not a guarantee of tagging quality or every MAT calculation.'
    if o.mode=='tagged' and tagged and penn==tagged and not bracket: warnings.append('Only Penn-style tag suffixes detected. Verify this is final MAT output, not an ST_ intermediate file.')
    if o.mode=='tagged' and baseline and baseline<o.ttr: warnings.append(f'Only {baseline} baseline tokens; choose a TTR window no larger than the shortest eligible file ({o.ttr} requested).')
    if o.mode=='tagged' and status=='Preflight passed' and re.search('[\u0085\u00a0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000]',text):
        status,bucket,reason='Review','review','Non-ASCII whitespace remains. Enable spacing normalization or inspect token separators before counting.'
    if o.mode=='tagged' and name.upper().startswith('ST_'):
        status,bucket,reason='Review','review','ST_ filename suggests Stanford intermediate output. Run the MAT tagging stage before counting.'
    return {'text':text,'status':status,'bucket':bucket,'reason':reason,'warnings':warnings,'audit':audit,'metrics':{'characters':len(text),'whitespace_tokens':len(tokens),'counter_baseline':baseline,'tagged_tokens':tagged,'untagged_tokens':untagged,'bracket_markers':bracket,'latin_letters':letters,'non_ascii':non_ascii},'examples':bad if o.mode=='tagged' else [],'outputName':safe_name(name,bucket=='count-input')}

def decode(data: bytes, encoding='auto'):
    if encoding!='auto': return data.decode(encoding),encoding
    if data.startswith((b'\xff\xfe',b'\xfe\xff')): return data.decode('utf-16'),'UTF-16 BOM'
    try: return data.decode('utf-8-sig'),'UTF-8'
    except UnicodeDecodeError: raise ValueError('Not valid UTF-8 / UTF-16 BOM. Select Windows-1252 explicitly if that is the actual source encoding.')

def unique_name(name, used):
    candidate, n = name, 2
    while candidate.casefold() in used:
        p=Path(name); stem=p.stem
        candidate=(stem[:-4]+f'-{n}_MAT.txt') if stem.endswith('_MAT') else f'{stem}-{n}{p.suffix}'
        n+=1
    used.add(candidate.casefold());return candidate

def run_batch(files, output_parent, options=None, encoding='auto', output_encoding='utf-8', stop=None, progress=None, max_mb=512):
    o=options or Options();stop=stop or threading.Event()
    parent=Path(output_parent);parent.mkdir(parents=True,exist_ok=True)
    root=parent/('Arc-MAT-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f'));root.mkdir(exist_ok=False)
    reports=[]; used={}; files=list(dict.fromkeys(Path(f).absolute() for f in files))
    for i,p in enumerate(files):
        if stop.is_set(): break
        record={'source':str(p),'name':p.name,'output':''}
        try:
            if p.suffix.lower()!='.txt' or not p.is_file() or p.is_symlink(): raise ValueError('Use a regular .txt file; symlinks are skipped.')
            if p.stat().st_size>max_mb*1048576: raise ValueError(f'Source exceeds {max_mb} MB. Split it before processing.')
            raw,detected=decode(p.read_bytes(),encoding);result=process(raw,o,p.name)
            record.update({k:v for k,v in result.items() if k!='text'},encoding=detected)
            try: data=result['text'].encode(output_encoding,errors='strict')
            except UnicodeEncodeError:
                record.update(status='Review',bucket='review',reason='Output is not representable in the requested encoding. UTF-8 review copy saved; no lossy replacement.');data=result['text'].encode('utf-8')
            folder=root/record['bucket'];folder.mkdir(exist_ok=True)
            name=unique_name(record['outputName'],used.setdefault(record['bucket'],set()))
            dest=folder/name
            temporary=None
            try:
                with tempfile.NamedTemporaryFile(dir=root,prefix='.arc-writing-',delete=False) as f:
                    temporary=Path(f.name);f.write(data)
                temporary.replace(dest);record['output']=str(dest.relative_to(root))
            finally:
                if temporary is not None:temporary.unlink(missing_ok=True)
        except Exception as e: record.update(status='Error',bucket='review',reason=str(e))
        reports.append(record)
        if progress:progress(i+1,len(files),record)
    (root/'audit.json').write_text(json.dumps({'tool':'Arc MAT Cleaner 1.0','options':asdict(o),'stopped':stop.is_set(),'records':reports},ensure_ascii=False,indent=2),encoding='utf-8')
    with (root/'report.csv').open('w',newline='',encoding='utf-8-sig') as f:
        fields=['source','status','bucket','output','counter_baseline','tagged_tokens','reason','warnings'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for r in reports:
            row={k:r.get(k,'') for k in fields};row['counter_baseline']=r.get('metrics',{}).get('counter_baseline','');row['tagged_tokens']=r.get('metrics',{}).get('tagged_tokens','');row['warnings']=' | '.join(r.get('warnings',[]))
            w.writerow({k:("'"+v if isinstance(v,str) and re.match(r'^\s*[=+@-]',v) else v) for k,v in row.items()})
    (root/'START-HERE.txt').write_text('Arc MAT Cleaner — independent utility, not the MAT tagger.\n\nready-for-tagging/: plain text. In MAT, use Tag or Tag and Analyze.\ncount-input/: only preflight-passed *_MAT.txt files. In MAT Count/Analyze, select THIS folder, not the output root.\nreview/: blocked or ambiguous files. Do not mix these into count-input.\nreport.csv and audit.json: outside MAT input folders. Originals are never overwritten.\n\nA nonzero baseline prevents the specific zero denominator detected by this preflight, but cannot guarantee every MAT installation or calculation. Re-tag incomplete files using MAT and its required Stanford/Java setup. TTR windows below 400 affect comparability; consult the MAT manual.\n',encoding='utf-8')
    return root,reports
