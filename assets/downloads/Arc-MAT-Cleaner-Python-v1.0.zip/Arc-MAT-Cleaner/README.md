# Arc MAT Cleaner 1.0

Offline Python desktop app and batch CLI by Dailwind Studio. Prepares English text for MAT and checks already-tagged input. **This utility is not the MAT tagger.** No Internet connection, API key, paid model or pip package is required.

## Open the desktop app

1. Install Python 3.10 or later with Tkinter. On Windows, the official Python installer normally includes Tcl/Tk. On Linux, install your distribution's Python Tk package if needed. On macOS, use a Python distribution with Tk support.
2. Extract the entire ZIP into a folder.
3. Windows: double-click `Start-Windows.bat`. Or open a terminal in this folder and run `py -3 app.py` / `python app.py`.
4. macOS/Linux: run `python3 app.py`. `Start-macOS.command` is also supplied; macOS may ask you to allow execution of your downloaded script.
5. Select files or a folder. Choose whether to include subfolders. Choose a NEW output parent folder and the correct workflow. Click **Clean & check files**.

The source files are never overwritten. Each run creates a fresh dated folder. No Windows EXE is included; Python must be installed.

## Two workflows

- **Plain text → tag first:** removes selected encoding/control artifacts and normalizes selected punctuation/spacing. Exports to `ready-for-tagging/`. In MAT, use **Tag** or **Tag and Analyze**. These files are not ready for Count/Analyze alone.
- **Already MAT-tagged → preflight:** keeps annotation spelling and token content, checks `word_TAG` syntax, filename convention and the counter's nonzero token baseline. Only eligible `*_MAT.txt` files go into `count-input/`. Select this folder in MAT counting, **never the whole output root**.
- **review/** contains blocked/ambiguous copies. `audit.json`, `report.csv` and `START-HERE.txt` sit outside MAT input folders. Duplicate filenames get unique names while preserving the `_MAT.txt` suffix.
- `ST_` intermediates, malformed tokens, empty files, and zero-baseline files are separated. Reports retain reasons and example tokens. Non-ASCII text is kept and flagged; nothing is transliterated or silently discarded.

## The screenshot error

The supplied screenshot reports `Illegal division by zero ... count_only.pl line 100`. In the examined official source, that line calculates average word length by dividing accumulated word length by the counted token total. A zero denominator is therefore consistent with that error. Your exact failing source file and installed MAT build were not supplied, so the specific cause remains unconfirmed.

The examined counter ignores punctuation-style tokens, bracketed feature markers, and `_POS` tokens when forming that baseline. This preflight mirrors those ASCII regex conditions; it does not reproduce every MAT feature, dimension or Z-score calculation. Empty or truncated tagger output, the wrong workflow or an intermediate file may need regeneration with MAT's Stanford/Java setup. **Cleaning cannot guarantee an error-free MAT run or fix a program installation.** Never add filler words, delete valid tags, rename untagged text to `_MAT.txt`, or change feature counts to avoid an error.

The TTR window here is a warning threshold, not a setting sent to MAT. The manual's default is 400. If you select a smaller value in MAT, interpretation and comparability can change; read the manual before doing so. Short texts are flagged rather than padded.

## Cleaning options

Defaults preserve word order, case, punctuation distinctions except the explicitly selected quote/dash mapping, numbers and stopwords. Controls, soft hyphens and excess whitespace have individual switches. Raw mode additionally offers printing ligatures/long-s expansion, optional line-end dehyphenation and optional placeholder removal. These can alter evidence: review their audit against the source. No missing words are invented. Tagged mode ignores these raw-only transformations. Spacing normalization converts Unicode spaces (including nonbreaking spaces) into ASCII separators; the examined legacy counter splits byte whitespace. If this option is disabled, problematic remaining separators are blocked or sent for review. Baseline checking is conservative and does not treat leading blank fields as real words.

Input decoding is strict: automatic UTF-8 or UTF-16 BOM detection. Select Windows-1252 explicitly for a known legacy file. If output cannot be represented in Windows-1252, a UTF-8 review copy is saved rather than replacing characters. Default output is UTF-8 without BOM. Newlines are LF, accepted as whitespace by the examined counter.

## Command line

```text
python app.py --input "C:\Corpus" --output "C:\Prepared" --mode raw
python app.py --input "C:\MAT_Output" --output "C:\Checked" --mode tagged --ttr 400
python app.py --input ./texts --output ./prepared --mode raw --recursive --encoding cp1252 --ligatures
```

Use `python app.py --help` for all options. File processing is sequential, with a default 512 MB source-file ceiling (CLI `--max-mb`, maximum 2,048). RAM and text complexity can reduce practical capacity; this is not a guarantee of handling a 2 GB text file. Stop finishes the current file and preserves a partial-run report. GUI selections ignore previous `Arc-MAT-*` output folders during folder scans.

## Verification

Core/CLI tests cover strict encoding, punctuation/marker-only zero baselines, malformed/plain/intermediate rejection, tagged preservation, raw preparation, filename collisions, separate output folders, CSV formula safety and original-file preservation. Browser and Python fixture outputs are compared. The GUI source is syntax checked; native Windows/macOS packaging and an end-to-end run of your installed MAT are not certified.

## References and independence

- Official MAT project: https://sites.google.com/site/multidimensionaltagger/
- Examined counter: https://github.com/andreanini/multidimensionalanalysistagger/blob/master/count_only.pl
- Manual: https://github.com/andreanini/multidimensionalanalysistagger/blob/master/Manual.pdf
- Nini, A. (2019). The Multi-Dimensional Analysis Tagger. In *Multi-Dimensional Analysis: Research Methods and Current Issues*, 67–94.

This is independently written Dailwind preparation software, not an official MAT product or endorsement. The MAT tagger, Stanford models and third-party program source are not bundled.
