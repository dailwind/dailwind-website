"""Run without arguments for desktop GUI, or use --help for batch CLI."""
import argparse, queue, sys, threading
from pathlib import Path
from core import Options, run_batch

def collect(paths, recursive=False):
    out=[]
    for value in paths:
        p=Path(value)
        if p.is_dir():
            out.extend(f for f in (p.rglob('*') if recursive else p.glob('*')) if f.is_file() and f.suffix.lower()=='.txt' and not any(part.startswith('Arc-MAT-') for part in f.parts))
        else:out.append(p)
    return sorted(set(out),key=lambda p:str(p).lower())

def gui():
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox
    root=tk.Tk();root.title('Arc MAT Cleaner · Dailwind Studio');root.geometry('1040x740');root.minsize(760,560);root.configure(bg='#f4f7fa')
    style=ttk.Style(root);style.theme_use('clam');style.configure('TFrame',background='#f4f7fa');style.configure('TLabel',background='#f4f7fa',foreground='#203449',font=('Segoe UI',10));style.configure('TButton',padding=(12,9),font=('Segoe UI',10));style.configure('Title.TLabel',font=('Segoe UI',25,'bold'));style.configure('Accent.TButton',background='#285b73',foreground='white');style.configure('TCheckbutton',background='#f4f7fa',font=('Segoe UI',10))
    root.columnconfigure(0,weight=1);root.rowconfigure(2,weight=1)
    top=ttk.Frame(root,padding=(24,18));top.grid(row=0,column=0,sticky='ew');ttk.Label(top,text='Arc MAT Cleaner',style='Title.TLabel').pack(anchor='w');ttk.Label(top,text='Prepare. Check. Tag with confidence.  ·  Offline, originals untouched.').pack(anchor='w',pady=(5,0))
    config=ttk.Frame(root,padding=(24,0));config.grid(row=1,column=0,sticky='ew');config.columnconfigure(1,weight=1)
    mode=tk.StringVar(value='raw');encoding=tk.StringVar(value='auto');output_encoding=tk.StringVar(value='utf-8');folder=tk.StringVar();ttr=tk.StringVar(value='400');status=tk.StringVar(value='Add text files or a folder. Choose plain-text preparation or tagged preflight.');recursive=tk.BooleanVar(value=False)
    ttk.Label(config,text='Workflow').grid(row=0,column=0,sticky='w',padx=(0,10));choices=ttk.Frame(config);choices.grid(row=0,column=1,sticky='w');ttk.Radiobutton(choices,text='Plain text → tag first',variable=mode,value='raw').pack(side='left',padx=(0,20));ttk.Radiobutton(choices,text='Already MAT-tagged → preflight',variable=mode,value='tagged').pack(side='left')
    row=ttk.Frame(config);row.grid(row=1,column=0,columnspan=2,sticky='ew',pady=12)
    ttk.Label(row,text='Input encoding').pack(side='left');ttk.Combobox(row,textvariable=encoding,values=['auto','utf-8','utf-16','utf-16-le','utf-16-be','cp1252'],state='readonly',width=13).pack(side='left',padx=(8,16));ttk.Label(row,text='Output').pack(side='left');ttk.Combobox(row,textvariable=output_encoding,values=['utf-8','cp1252'],state='readonly',width=10).pack(side='left',padx=(8,16));ttk.Label(row,text='TTR window').pack(side='left');ttk.Entry(row,textvariable=ttr,width=7).pack(side='left',padx=8)
    variables={}; rules=ttk.Frame(config);rules.grid(row=2,column=0,columnspan=2,sticky='ew')
    for i,(key,label,default) in enumerate([('controls','Remove controls / zero-width artifacts',True),('softHyphens','Remove soft hyphens',True),('spacing','Normalize spaces / blank lines',True),('punctuation','Standardize quotes / punctuation (raw)',True),('ligatures','Expand ligatures / long s (raw)',False),('dehyphenate','Join wrapped hyphens (raw; review)',False),('boxes','Remove OCR placeholders (raw; review)',False)]):
        variables[key]=tk.BooleanVar(value=default);ttk.Checkbutton(rules,text=label,variable=variables[key]).grid(row=i//2,column=i%2,sticky='w',padx=(0,20),pady=3)
    middle=ttk.Frame(root,padding=(24,14));middle.grid(row=2,column=0,sticky='nsew');middle.rowconfigure(1,weight=1);middle.columnconfigure(0,weight=1)
    controls=ttk.Frame(middle);controls.grid(row=0,column=0,sticky='ew',pady=(0,10));files=[];state={'busy':False};events=queue.Queue();stop=threading.Event()
    tree=ttk.Treeview(middle,columns=('file','result','tokens'),show='headings',selectmode='extended');tree.heading('file',text='Source file');tree.heading('result',text='Result / workflow');tree.heading('tokens',text='Counter baseline');tree.column('file',width=520);tree.column('result',width=190);tree.column('tokens',width=120);tree.grid(row=1,column=0,sticky='nsew');scroll=ttk.Scrollbar(middle,orient='vertical',command=tree.yview);scroll.grid(row=1,column=1,sticky='ns');tree.configure(yscrollcommand=scroll.set)
    def add(values):
        if state['busy']:return
        for p in values:
            if p not in files:files.append(p);tree.insert('', 'end',iid=str(len(files)-1),values=(str(p),'Pending','—'))
        status.set(f'{len(files)} text files selected. Originals will not be changed.')
    def add_files():add(collect(filedialog.askopenfilenames(title='Select text files',filetypes=[('Text files','*.txt')]),False))
    def add_folder():
        p=filedialog.askdirectory(title='Select source folder')
        if p:add(collect([p],recursive.get()))
    def clear():
        if state['busy']:return
        files.clear();tree.delete(*tree.get_children());status.set('Selection cleared.')
    ttk.Button(controls,text='Add files',command=add_files).pack(side='left');ttk.Button(controls,text='Add folder',command=add_folder).pack(side='left',padx=8);ttk.Checkbutton(controls,text='Include subfolders',variable=recursive).pack(side='left',padx=8);ttk.Button(controls,text='Clear',command=clear).pack(side='right')
    bottom=ttk.Frame(root,padding=(24,0,24,20));bottom.grid(row=3,column=0,sticky='ew');bottom.columnconfigure(1,weight=1)
    ttk.Label(bottom,text='Save inside').grid(row=0,column=0,sticky='w');ttk.Entry(bottom,textvariable=folder,state='readonly').grid(row=0,column=1,sticky='ew',padx=10)
    def choose_output():
        if state['busy']:return
        p=filedialog.askdirectory(title='Choose output parent; a NEW dated folder is created')
        if p:folder.set(p)
    ttk.Button(bottom,text='Choose folder',command=choose_output).grid(row=0,column=2)
    progress=ttk.Progressbar(bottom,mode='determinate',maximum=1);progress.grid(row=1,column=0,columnspan=3,sticky='ew',pady=12)
    message=ttk.Label(bottom,textvariable=status,wraplength=950);message.grid(row=2,column=0,columnspan=3,sticky='ew');ttk.Label(bottom,text='Not a tagger. No fabricated words/tags. Preflight cannot guarantee every MAT calculation.',font=('Segoe UI',9)).grid(row=3,column=0,columnspan=3,sticky='w',pady=(7,10))
    def run():
        if state['busy']:return
        if not files or not folder.get():return messagebox.showinfo('Select files and output','Add .txt files and choose an output folder first.')
        try:window=int(ttr.get());assert 1<=window<=1000000
        except (ValueError,AssertionError):return messagebox.showerror('TTR window','Enter 1–1,000,000. This is a warning threshold, not a change to MAT settings.')
        options=Options(mode=mode.get(),ttr=window,**{k:v.get() for k,v in variables.items()});source_snapshot=list(files);output_parent=folder.get();input_encoding=encoding.get();out_encoding=output_encoding.get();state['busy']=True;stop.clear();run_button.configure(state='disabled');status.set('Processing locally…')
        def work():
            try:result=run_batch(source_snapshot,output_parent,options,input_encoding,out_encoding,stop,lambda a,b,r:events.put(('progress',a,b,r)));events.put(('done',result))
            except Exception as e:events.put(('error',str(e)))
        threading.Thread(target=work,daemon=True).start()
    run_button=ttk.Button(bottom,text='Clean & check files',style='Accent.TButton',command=run);run_button.grid(row=4,column=1,sticky='e');ttk.Button(bottom,text='Stop after current file',command=stop.set).grid(row=4,column=2,padx=(10,0))
    def poll():
        try:
            while True:
                event=events.get_nowait()
                if event[0]=='progress':
                    _,a,b,r=event;progress.configure(value=a/max(1,b));tree.item(str(a-1),values=(r['name'],r['status'],r.get('metrics',{}).get('counter_baseline','—')));status.set(f'{a}/{b} · {r["name"]} · {r["status"]}')
                else:
                    state['busy']=False;run_button.configure(state='normal')
                    if event[0]=='done':status.set('Stopped. ' + str(event[1][0]) if stop.is_set() else 'Complete. Saved to '+str(event[1][0]));messagebox.showinfo('Output ready',str(event[1][0])+'\n\nRead START-HERE.txt. Select count-input only for counting, never the output root.')
                    else:status.set(event[1]);messagebox.showerror('Could not finish',event[1])
        except queue.Empty:pass
        root.after(100,poll)
    def close():
        if state['busy']:
            if not messagebox.askyesno('Processing is active','Stop and close? The current file may not finish writing its report.'):return
            stop.set()
        root.destroy()
    root.protocol('WM_DELETE_WINDOW',close);root.bind('<Configure>',lambda e:message.configure(wraplength=max(400,root.winfo_width()-70)));poll();root.mainloop()

def main():
    if len(sys.argv)==1:return gui()
    p=argparse.ArgumentParser(description='Arc MAT Cleaner: offline preparation/preflight, not a tagger. Without arguments opens the desktop GUI.')
    p.add_argument('--input',nargs='+',required=True);p.add_argument('--output',required=True);p.add_argument('--mode',choices=['raw','tagged'],default='raw');p.add_argument('--encoding',default='auto',choices=['auto','utf-8','utf-16','utf-16-le','utf-16-be','cp1252']);p.add_argument('--output-encoding',default='utf-8',choices=['utf-8','cp1252']);p.add_argument('--ttr',type=int,default=400);p.add_argument('--recursive',action='store_true');p.add_argument('--ligatures',action='store_true');p.add_argument('--dehyphenate',action='store_true');p.add_argument('--boxes',action='store_true');p.add_argument('--max-mb',type=int,default=512)
    a=p.parse_args()
    if not 1<=a.ttr<=1000000 or not 1<=a.max_mb<=2048:p.error('TTR must be 1–1,000,000; max-mb must be 1–2,048.')
    files=collect(a.input,a.recursive)
    if not files:p.error('No .txt files found.')
    root,records=run_batch(files,a.output,Options(mode=a.mode,ttr=a.ttr,ligatures=a.ligatures,dehyphenate=a.dehyphenate,boxes=a.boxes),a.encoding,a.output_encoding,max_mb=a.max_mb)
    print(root);print(f'{len(records)} files processed; {sum(r["bucket"]=="review" for r in records)} need review.')
    return int(any(r['status']=='Error' for r in records))

if __name__=='__main__':raise SystemExit(main() or 0)
